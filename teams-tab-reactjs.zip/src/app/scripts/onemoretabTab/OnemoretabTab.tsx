import * as React from "react";
import { Provider, Flex, Text, Button, Header } from "@fluentui/react-northstar";
import TeamsBaseComponent, { ITeamsBaseComponentState } from "msteams-react-base-component";
import * as microsoftTeams from "@microsoft/teams-js";
import * as Msal from "msal";

const msalConfig = {
    auth: {
      clientId: "856df42f-34e8-49db-8c05-7e2903154b55"
    //   redirectUri: "https://c20c9735949a.ngrok.io/onemoretabTab"
    }
};

const groupConfig = {
    displayName: "random team name",
    description: "a name choosen wisely",
    groupTypes: ("Unified"),
    mailEnabled: true,
    securityEnabled: false
};

const createRequest = {
    scopes: ["Group.ReadWrite.All"]
};

const loginRequest = {
    scopes: ["openid", "profile", "User.Read"]
};

// Add here scopes for access token to be used at MS Graph API endpoints.
const tokenRequest = {
    scopes: ["Mail.Read"]
};

const graphConfig = {
    graphMeEndpoint: "https://graph.microsoft.com/v1.0/me",
    graphMailEndpoint: "https://graph.microsoft.com/v1.0/me/messages",
    graphCreateGroup: "https://graph.microsoft.com/v1.0/groups//teams"
};


const myMSALObj = new Msal.UserAgentApplication(msalConfig);

/**
 * State for the onemoretabTabTab React component
 */
export interface IOnemoretabTabState extends ITeamsBaseComponentState {
    entityId?: string;
    renderText?: string;
}

/**
 * Properties for the onemoretabTabTab React component
 */
export interface IOnemoretabTabProps {

}

/**
 * Implementation of the onemoretab Tab content page
 */
export class OnemoretabTab extends TeamsBaseComponent<IOnemoretabTabProps, IOnemoretabTabState> {

    public async componentWillMount() {
        this.updateTheme(this.getQueryVariable("theme"));


        if (await this.inTeams()) {
            microsoftTeams.initialize();
            microsoftTeams.registerOnThemeChangeHandler(this.updateTheme);
            microsoftTeams.getContext((context) => {
                microsoftTeams.appInitialization.notifySuccess();
                this.setState({
                    entityId: context.entityId,
                    renderText: "click on 'see pofile' or 'read mail' to load data"
                });
                this.updateTheme(context.theme);
            });
        } else {
            this.setState({
                entityId: "This is not hosted in Microsoft Teams",
                renderText: "click on 'see pofile' or 'read mail' to load data"
            });
        }
    }
    public signIn = () => {
        myMSALObj.loginPopup(loginRequest)
        .then(loginResponse => {
        console.log("id_token acquired at: " + new Date().toString());
        console.log(loginResponse);
        if (myMSALObj.getAccount()) {
            console.log(myMSALObj.getAccount());
        }
        }).catch(error => {
        console.log(error);
        });
    }
    public signOut = () => {
        myMSALObj.logout();
    }
    public callMSGraph = (theUrl, accToken, callback) => {
        const xmlHttp = new XMLHttpRequest();
        xmlHttp.onreadystatechange = function() {
            if (this.readyState === 4 && this.status === 200) {
                callback(this.responseText);
            }
        };
        xmlHttp.open("GET", theUrl, true);
        xmlHttp.setRequestHeader("Authorization", "Bearer " + accToken.accessToken);
        xmlHttp.send();
    }
    public getTokenPopup = (request) => {
        return myMSALObj.acquireTokenSilent(request).catch(error => {
        console.log(error);
        console.log("silent token acquisition fails. acquiring token using popup");
        // fallback to interaction when silent call fails
        return myMSALObj.acquireTokenPopup(request).then(tokenResponse => {
            return tokenResponse;
        }).catch(err1 => {
            console.log(err1);
        });
        });
    }
    public updateUI = (res) => {
        this.setState({
            renderText: res
        });
    }
    public seeProfile = () => {
        if (myMSALObj.getAccount()) {
            this.getTokenPopup(loginRequest)
            .then(response => {
                this.callMSGraph(graphConfig.graphMeEndpoint, response, this.updateUI);
            }).catch(err2 => {
                console.log(err2);
            });
        }
    }
    public readMail = () => {
        if (myMSALObj.getAccount()) {
            this.getTokenPopup(tokenRequest)
            .then(response => {
                this.callMSGraph(graphConfig.graphMailEndpoint, response, this.updateUI);
            }).catch(error3 => {
                console.log(error3);
            });
        }
    }
    public callGraphForGroup = (theUrl, accToken, callback) => {
        const xmlHttp = new XMLHttpRequest();
        xmlHttp.onreadystatechange = function() {
            if (this.readyState === 4 && this.status === 200) {
                callback(this.responseText);
            }
        };
        xmlHttp.open("POST", theUrl, true);
        xmlHttp.setRequestHeader("Authorization", "Bearer " + accToken.accessToken);
        xmlHttp.send(JSON.stringify(groupConfig));
    }
    public createGroup = () => {
        if (myMSALObj.getAccount()) {
            this.getTokenPopup(createRequest)
            .then(response => {
                this.callGraphForGroup(graphConfig.graphCreateGroup, response, this.updateUI);
            }).catch(error4 => {
                console.log(error4);
            });
        }
    }
    /**
     * The render() method to create the UI of the tab
     */
    public render() {
        return (
            <Provider theme={this.state.theme}>
                <Flex fill={true} column styles={{
                    padding: ".8rem 0 .8rem .5rem"
                }}>
                    <Flex.Item>
                        <Header content="This is your tab" />
                    </Flex.Item>
                    <Flex.Item>
                        <div>

                            <div>
                                <Text content={this.state.entityId} />
                            </div>

                            <div>
                                <Button onClick={this.signIn}>sign in</Button>
                                <Button onClick={this.signOut}>sign out</Button>
                                <Button onClick={this.seeProfile}>see profile</Button>
                                <Button onClick={this.readMail}>read mail</Button>
                                <Button onClick={this.createGroup}>create group</Button>
                            </div>

                            <div>
                                <Text content={this.state.renderText} />
                            </div>
                        </div>
                    </Flex.Item>
                    <Flex.Item styles={{
                        padding: ".8rem 0 .8rem .5rem"
                    }}>
                        <Text size="smaller" content="(C) Copyright axonfactory" />
                    </Flex.Item>
                </Flex>
            </Provider>
        );
    }
}
