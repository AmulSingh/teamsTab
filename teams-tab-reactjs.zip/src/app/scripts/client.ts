// Automatically added for the onemoretabTab tab
export * from "./onemoretabTab/OnemoretabTab";
export * from "./onemoretabTab/OnemoretabTabConfig";
export * from "./onemoretabTab/OnemoretabTabRemove";
